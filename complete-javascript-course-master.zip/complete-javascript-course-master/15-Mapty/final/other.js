const firstName = 'Jonas';
console.log(months);
